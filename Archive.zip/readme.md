## 소개
타입스크립트로 만든 파일·DB 하이브리드 블로그. 공개 페이지(목록/태그/글/RSS)는 서버에서 HTML로 렌더링하고, 로컬(Express)·Vercel(Serverless)·Docker를 동시 타깃으로 운용할 수 있는 것을 목표로 함. 데이터는 PostgreSQL(+ Drizzle ORM)로 관리하고, 글 작성/배포는 비밀번호 기반의 미니 에디터로 처리한다.

## 핵심 기능

- 메인 인덱스(/)·태그 목록(/tag/:tag)·글 상세(/post/:slug) SSR 렌더링
- RSS 피드(/rss.xml)
- 간이 에디터 페이지(/editor): 패스워드 입력 → 글 목록/검색/미리보기/퍼블리시
- 에디터 API(/api/posts…): GET/POST/PATCH/DELETE로 글 CRUD
- 파일 업로드 엔드포인트 골격만 존재(현재 501: 구현 보류)
- BibTeX 인용 처리: 본문에 [@key] 형태 → 본문 치환 + 참고문헌 섹션 생성
- 태그 UI/필터 레일, 배너 레일, OG 메타 태그 유틸 포함
- 정적 자산: /public/assets(CSS/JS) 제공

## 디렉터리 구조
- routes/public/* — 페이지 라우트 렌더러(인덱스/태그/포스트/RSS)
- views/pageview.ts — 단일 글 페이지 HTML 빌더
- lib/db/* — DB 클라이언트/스키마/부트스트랩(SQL), Drizzle 스키마
- lib/render/* — 공통 HTML 레이아웃, 태그/배너/OG 등 렌더 유틸
- lib/api/editor.ts — 에디터용 REST API(글 CRUD)
- lib/pages/editor.ts — 에디터 HTML(클라이언트 스크립트 인라인 포함)
- public/assets/* — 정적 스타일/스크립트
- server/server.ts — 로컬 Express 진입점
- api/[[...all]].ts — Vercel 엔드포인트
- worker.ts — Cloudflare Worker 엔트리
- drizzle.config.ts / lib/db/schema.ts / lib/db/schema.sql — DB 스키마/마이그레이션

## 런타임/배포 타깃
- 로컬 개발(Express): server/server.ts, WHATWG Fetch Response 기반 렌더러를 Express로 브리지해서 응답
- Vercel(Serverless): api/[[...all]].ts가 모든 공개 라우트 위임, /api/posts* API 제공
- Docker(dev): docker-compose.yml(Postgres + 앱), Dockerfile(Miniflare로 워커 에뮬)

## 데이터 모델(핵심 테이블: posts)

- id bigserial
- slug text unique
- title text, body_md text, excerpt text, cover_url text
- tags text[](GIN 인덱스), is_page boolean(페이지/포스트 구분)
- published boolean, published_at timestamptz(트리거로 자동 설정)
- created_at/updated_at(업데이트 트리거로 자동 갱신)

목록·태그·단일 글 조회 쿼리와 인덱스가 준비되어 있음.

## 환경 변수
- 사이트/기능: SITE_NAME, SITE_URL, NOTES_TAGS, ALLOW_DEBUG, BIBTEX_FILE, BIBTEX_STYLE, SITE_BANNERS, BANNERS_JSON_URL
- 에디터: EDITOR_PASSWORD(헤더 x-editor-token과 매칭), EDITOR_ASSET_VER
- DB: NEON_DATABASE_URL → 없으면 DATABASE_URL 사용, DB_CLIENT(강제 드라이버 선택)

## TODO
- [ ] 정적 파일 제공 방식 하나로 통일
자바스크립트로 “정적 에셋 라우터”를 돌리려다 중간에 멈춘 흔적이 있어요. Express의 기본 정적 서빙만 써도 충분함.
```
public/assets 폴더만 두고, Express에 다음 한 줄 추가
app.use('/assets', express.static('public/assets'));
```
만약 routes/assets.js(ts)를 임포트하고 있다면 제거

- [ ] 데이터베이스 사용 방식 하나로

“부트스트랩 SQL”이랑 “Drizzle 마이그레이션”을 섞어 쓰지 말고 하나만 쓰면 실수가 줄어요. 권장: Drizzle 하나로 통일.

Drizzle만 쓸 경우 db:bootstrap 같은 스크립트 제거. drizzle:generate → drizzle:migrate 흐름으로 고정

만약 SQL 파일로 초기화하고 싶다면 db/schema.sql을 실제 스키마로 채우고, db-bootstrap.ts는 그 파일만 실행하도록 단순화(둘 중 하나만 선택)

- [ ] 라우트와 CSS/JS의 동작을 맞추기(모바일 사이드 패널)

지금은 CSS는 body에 side-open이 붙었을 때 열리도록 되어 있는데, JS는 패널 요소에 open을 붙였다 뗐다 해요. 기준을 하나로. 쉬운 방법: JS가 body에 side-open 클래스를 붙이도록 바꾸기
그리고 바깥 어두운 영역(백드롭) 클릭이나 ESC 키로 닫히게 이벤트 추가

이렇게 하면 “닫히지 않는다” 문제가 깔끔히 해결돼요

1) 풋노트 툴팁이 본문과 함께 보이는 문제

툴팁은 원래 마우스를 올릴 때만 보여야 해요. 다른 CSS 영향으로 기본이 드러난다면 다음처럼 “초기화 후 스타일 다시 지정”을 써요.

.footnote-tip에 all: unset;을 주고, display:none을 기본값으로

:hover 또는 :focus-within일 때만 display:block

10) RSS의 절대 URL

RSS는 구독 앱에서 열리니, 링크가 절대 주소여야 해요.

.env에 SITE_URL=https://example.com 같은 값을 두고

RSS 생성 시 링크 앞에 항상 SITE_URL을 붙여 “절대 경로”로 만들기

- [ ] 에디터(간단 CMS) 마무리

에디터 페이지와 API는 연결되어야 해요. 에디터 페이지가 API를 호출할 때, 요청 헤더에 x-editor-token: <EDITOR_PASSWORD>를 붙이도록 되어 있는지 확인. 게시/수정/삭제 후 리스트가 갱신되는지(캐시 끄기 또는 갱신 처리)

- [ ] 스크립트 최소 세트(사람이 쓰기 쉬운 버튼 모음) package.json에 다음 정도만 남기면 헷갈리지 않아요.

dev: 로컬 개발 서버(Express)

typecheck: 타입 검사만

build: 서버 코드 빌드(필요시)

start: 빌드 산출물 실행(프로덕션)

docker:up / docker:down: 도커로 통합 실행/중지

db:migrate: Drizzle 마이그레이션 실행

- [ ] 문서 정리(README)

한 페이지짜리 “사용 설명서”가 있으면, 나중에 어디에 배포하든 덜 헤매요.

로컬 실행: 필요 소프트웨어, 명령 한 줄

Vercel 배포: 환경변수 어디에 넣는지, 어떤 파일이 엔드포인트인지

Docker 실행: docker compose up -d로 끝, 접속 주소

문제 해결: 포트 충돌, DB 접속 오류, 비밀번호 분실 시 조치


## 파일 이동/삭제 계획
- [x] server/server.ts만 남기고 dev 진입점을 여기에 고정한다.
- [x] api/[[...all]].ts로 Vercel 요청을 모두 받아 공개 라우트로 위임한다.
- [x] public/assets만 남기고, 코드 기반 정적 라우터 파일은 삭제한다.
- [x] Workers 관련 파일과 wrangler 설정은 전부 삭제한다.
- [x] drizzle-kit(마이그레이션 도구), drizzle.config.ts, drizzle/ 폴더, drizzle:* 스크립트는 제거.
- [x] lib/db/schema.sql이 없었다면 추가한다. 기존 Drizzle 스키마 내용과 동일하게 만든다.
## 정비 리스트
- [ ] 패키지 정리: 코드에서 쓰는 모듈(express, pg, 마크다운 변환기 등)이 dependencies에 모두 있는지 확인하고, 쓰지 않는 패키지는 제거한다.
- [ ] README 1장: 로컬 실행, Vercel 배포, Docker 실행, DB 초기화, 흔한 오류(포트 충돌/DB 연결 실패)를 한 페이지에 정리한다.

## 정비 리스트
- [ ] 공개 검색 라우트 추가: GET /search?q=…로 title/body_md ILIKE 검색을 먼저 붙이고, 나중에 풀텍스트(tsvector)로 확장한다.
- [ ] 접근성 강화: 사이드 패널에 포커스 트랩을 두고, 키보드 탭 순서를 점검한다.
- [ ] 간단 헬스체크: 루트/글/태그/RSS를 fetch해 200인지 확인하는 스크립트를 하나 둔다.
- [ ] Docker 품질: 멀티스테이지 빌드, 비루트 사용자, HEALTHCHECK, depends_on + healthcheck로 DB 대기.
- [ ] 배너/푸터: 공통 영역을 뷰 유틸로 묶어 재사용한다.
- [ ] 공개 검색을 붙일 계획(선택)

```
라우트: routes/public/search.ts(예: GET /search?q=키워드&page=2).
쿼리: published=true and (title ilike $1 or body_md ilike $1) with limit/offset.
뷰: 기존 목록 렌더를 재사용하고, 하이라이트는 선택.
```