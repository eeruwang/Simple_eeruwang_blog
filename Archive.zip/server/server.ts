// server/server.ts
// 로컬 개발용 Express 서버 (TS/ESM, Node 18+)

import express, { type Request as ExRequest, type Response as ExResponse } from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";

// 환경
import { loadEnv } from "../lib/env.js";

// 페이지 라우트 (WHATWG Response 반환 유틸)
import { renderIndex } from "../routes/public/index.js";
import { renderTag } from "../routes/public/tag.js";
import { renderPost } from "../routes/public/post.js";
import { renderPage } from "../routes/public/page.js";
import { renderRSS } from "../routes/public/rss.js";

// 에디터 페이지 라우트 마운터
import { renderEditorHTML } from "../lib/pages/editor.js";

// 에디터 보호 API
import { handleEditorApi } from "../lib/api/editor.js";
import type { Env as EditorEnv } from "../lib/api/editor.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const env = loadEnv();

// ---- WHATWG Response -> Express ----
async function sendFetchResponse(res: ExResponse, r: globalThis.Response) {
  res.status(r.status);
  r.headers.forEach((v, k) => res.setHeader(k, v));
  // 공통 보안 헤더 (마지막에 보강)
  setSecurityHeadersExpress(res);
  const buf = Buffer.from(await r.arrayBuffer());
  res.send(buf);
}

// ---- Express req -> WHATWG Request ----
async function toWebRequest(req: ExRequest): Promise<Request> {
  const url = `${req.protocol}://${req.get("host")}${req.originalUrl}`;
  const headers = new Headers();
  for (const [k, v] of Object.entries(req.headers)) {
    if (v === undefined) continue;
    headers.set(k, Array.isArray(v) ? v.join(", ") : String(v));
  }

  let bodyAb: ArrayBuffer | undefined = undefined;
  if (req.method !== "GET" && req.method !== "HEAD") {
    const chunks: Uint8Array[] = [];
    await new Promise<void>((resolve) => {
      req.on("data", (c) => chunks.push(c));
      req.on("end", () => resolve());
    });
    const buf = Buffer.concat(chunks);
    bodyAb = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
  }

  return new Request(url, { method: req.method, headers, body: bodyAb });
}

/* HTML이면 cache-control: no-store 강제 */
async function withNoStore(resp: globalThis.Response): Promise<globalThis.Response> {
  const ct = resp.headers.get("content-type") || "";
  if (!/text\/html/i.test(ct)) return resp;
  const h = new Headers(resp.headers);
  if (!h.has("cache-control")) h.set("cache-control", "no-store");
  const buf = await resp.arrayBuffer();
  return new Response(buf, { status: resp.status, headers: h });
}

/* HTML 응답에 /assets/site.js 자동 주입 (개발 서버도 동일하게) */
async function withSiteJs(resp: globalThis.Response): Promise<globalThis.Response> {
  const ct = resp.headers.get("content-type") || "";
  if (!/text\/html/i.test(ct)) return resp;

  const html = await resp.text();
  if (/\/assets\/site\.js/i.test(html)) {
    const h = new Headers(resp.headers);
    return new Response(html, { status: resp.status, headers: h });
  }

  const inject = `<script src="/assets/site.js" defer></script>`;
  const patched = html.includes("</body>")
    ? html.replace("</body>", `${inject}\n</body>`)
    : `${html}\n${inject}\n`;

  const headers = new Headers(resp.headers);
  if (!headers.get("content-type")) {
    headers.set("content-type", "text/html; charset=utf-8");
  }
  return new Response(patched, { status: resp.status, headers });
}

/* ── 보안 헤더 & CORS 유틸 ── */
function setSecurityHeadersExpress(res: ExResponse) {
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "geolocation=(), microphone=(), camera=()");
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
  res.setHeader("Cross-Origin-Resource-Policy", "same-origin");
}

function originOf(u?: string | null): string | null {
  if (!u) return null;
  try { return new URL(u).origin; } catch { return null; }
}
function sameSiteOrigin(req: ExRequest): string | null {
  const site = (process.env.SITE_URL || `${req.protocol}://${req.get("host")}`).replace(/\/+$/, "");
  return originOf(site);
}
function applyCorsIfSameOrigin(req: ExRequest, res: ExResponse) {
  const reqOrigin = originOf(req.headers.origin as string | undefined);
  const allow = sameSiteOrigin(req);
  if (reqOrigin && allow && reqOrigin === allow) {
    res.setHeader("Access-Control-Allow-Origin", reqOrigin);
    res.setHeader("Vary", "Origin");
  }
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-Editor-Token, X-Editor-Key");
  res.setHeader("Access-Control-Max-Age", "600");
}

// ---- 정적 파일 서빙 (public/assets/*) — SSR 라우트보다 위에! ----
const ASSETS_DIR = path.join(__dirname, "..", "public", "assets");
app.use(
  "/assets",
  express.static(ASSETS_DIR, {
    etag: true,
    lastModified: true,
    maxAge: "1y",
    immutable: true,
    setHeaders(res, filePath) {
      if (/\.(html|map|json)$/i.test(filePath)) {
        res.setHeader("cache-control", "no-store");
      }
      if (filePath.endsWith(".xml")) {
        res.setHeader("content-type", "application/xml; charset=utf-8");
      }
    },
  })
);

// ── 공통 보안 헤더(모든 응답) ──
app.use((_, res, next) => { setSecurityHeadersExpress(res); next(); });

// ----------------- 공개 페이지 라우트 -----------------
app.get("/api/ping", (_req, res) => res.json({ ok: true }));

app.get("/", async (req, res) => {
  const page = Number(req.query.page || "1") || 1;
  const r = await renderIndex(env, page);
  await sendFetchResponse(res, await withNoStore(await withSiteJs(r)));
});

app.get("/tag/:tag", async (req, res) => {
  const page = Number(req.query.page || "1") || 1;
  const r = await renderTag(env as any, req.params.tag, page);
  await sendFetchResponse(res, await withNoStore(await withSiteJs(r)));
});

app.get("/post/:slug", async (req, res) => {
  const r = await renderPost(
    env as any,
    req.params.slug,
    new URL(req.url, `${req.protocol}://${req.get("host")}`).searchParams
  );
  await sendFetchResponse(res, await withNoStore(await withSiteJs(r)));
});

app.get("/rss.xml", async (req, res) => {
  const base = (process.env.SITE_URL && process.env.SITE_URL.replace(/\/+$/, "")) ||
               `${req.protocol}://${req.get("host")}`;
  const r = await renderRSS({ ...env, SITE_URL: base } as any);
  if (!r.headers.get("content-type")) {
    const rr = new Response(await r.text(), {
      status: r.status,
      headers: { "content-type": "application/rss+xml; charset=utf-8" },
    });
    return sendFetchResponse(res, rr);
  }
  await sendFetchResponse(res, r);
});

// ✅ /editor (HTML no-store 유지)
app.get("/editor", (req, res) => {
  let html = renderEditorHTML({ version: process.env.EDITOR_ASSET_VER || "v8" });

  if (!/\/assets\/editor\.js/.test(html)) {
    const inject = `<script src="/assets/editor.js" defer></script>`;
    html = html.includes("</body>")
      ? html.replace("</body>", `${inject}\n</body>`)
      : `${html}\n${inject}\n`;
  }

  res.setHeader("content-type", "text/html; charset=utf-8");
  res.setHeader("cache-control", "no-store");
  res.status(200).send(html);
});

// 단일 세그먼트 페이지(/about 등) — 예약 경로 스킵
app.get("/:slug", async (req, res, next) => {
  const p = req.path;
  const reserved =
    p.startsWith("/post/") ||
    p.startsWith("/tag/") ||
    p.startsWith("/assets/") ||
    p.startsWith("/api/") ||
    p === "/editor" ||
    p === "/rss.xml" ||
    p === "/favicon.ico" ||
    p === "/robots.txt" ||
    p === "/sitemap.xml";

  if (reserved) return next();

  const r = await renderPage(
    env as any,
    req.params.slug,
    new URL(req.url, `${req.protocol}://${req.get("host")}`).searchParams
  );
  await sendFetchResponse(res, await withNoStore(await withSiteJs(r)));
});

// ----------------- 에디터 API CORS 프리플라이트 -----------------
app.options(/^\/api\/posts(?:\/.*)?$/, (req, res) => {
  applyCorsIfSameOrigin(req, res);
  res.status(204).end();
});

// ----------------- 에디터 API (/api/posts*) -----------------
app.all(/^\/api\/posts(?:\/.*)?$/, async (req, res) => {
  applyCorsIfSameOrigin(req, res); // 자기 도메인만 허용
  const webReq = await toWebRequest(req);
  const r = await handleEditorApi(webReq, process.env as unknown as EditorEnv);
  await sendFetchResponse(res, r);
});

// ----------------- 루트 정적 파일 서빙 -----------------
app.get("/favicon.ico", (_req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "favicon.ico"));
});
app.get("/robots.txt", (_req, res) => {
  res.type("text/plain; charset=utf-8");
  res.sendFile(path.join(__dirname, "..", "public", "robots.txt"));
});
app.get("/sitemap.xml", (_req, res) => {
  res.type("application/xml; charset=utf-8");
  res.sendFile(path.join(__dirname, "..", "public", "sitemap.xml"));
});

app.disable("x-powered-by");

// ----------------- 서버 시작 -----------------
const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;
app.listen(PORT, () => {
  console.log(`dev server on http://localhost:${PORT}`);
});

export default app;
