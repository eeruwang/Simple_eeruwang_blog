// lib/env.ts

export type AppEnv = {
  SITE_NAME: string;
  SITE_URL: string;
  NOTES_TAGS?: string;
  ALLOW_DEBUG: boolean;          // ← 항상 boolean으로 전달
  BIBTEX_FILE?: string;
  BIBTEX_STYLE?: string;

  EDITOR_PASSWORD?: string;
  EDITOR_ASSET_VER?: string;     // 에디터 캐시버스터 (선택)

  // 배너(옵션)
  SITE_BANNERS?: string;         // JSON 또는 "href|label|image" 시퀀스
  BANNERS_JSON_URL?: string;     // 외부 JSON 경로

  // Noco(이전) — 제거 예정이지만 호환 위해 남김
  NOCO_BASE_URL?: string;
  NOCO_TABLE_ID?: string;
  NOCO_VIEW_ID?: string;
  NOCO_TOKEN?: string;

  // Postgres
  DATABASE_URL?: string;         // NEON_DATABASE_URL 우선 병합
  NEON_DATABASE_URL?: string;    // 선택
  DB_CLIENT?: "neon" | "pg";     // 강제 드라이버 선택(선택)
};

function getEnv(k: string): string | undefined {
  // Edge에서도 안전하게 접근
  return (globalThis as any).process?.env?.[k];
}

function parseBool(v: unknown, dflt = false): boolean {
  if (typeof v === "boolean") return v;
  if (typeof v !== "string") return dflt;
  const s = v.trim().toLowerCase();
  return s === "1" || s === "true" || s === "yes" || s === "y" || s === "on";
}

export function loadEnv(): AppEnv {
  const SITE_URL = getEnv("SITE_URL") || "http://localhost:8787";

  // DATABASE_URL 병합 규칙: NEON_DATABASE_URL > DATABASE_URL
  const NEON_DATABASE_URL = getEnv("NEON_DATABASE_URL");
  const DATABASE_URL = NEON_DATABASE_URL || getEnv("DATABASE_URL");

  const out: AppEnv = {
    SITE_NAME: getEnv("SITE_NAME") || "Site",
    SITE_URL,
    NOTES_TAGS: getEnv("NOTES_TAGS"),
    ALLOW_DEBUG: parseBool(getEnv("ALLOW_DEBUG"), false),
    BIBTEX_FILE: getEnv("BIBTEX_FILE"),
    BIBTEX_STYLE: getEnv("BIBTEX_STYLE") || "harvard",

    EDITOR_PASSWORD: getEnv("EDITOR_PASSWORD"),
    EDITOR_ASSET_VER: getEnv("EDITOR_ASSET_VER"),

    SITE_BANNERS: getEnv("SITE_BANNERS"),
    BANNERS_JSON_URL: getEnv("BANNERS_JSON_URL"),

    NOCO_BASE_URL: getEnv("NOCO_BASE_URL"),
    NOCO_TABLE_ID: getEnv("NOCO_TABLE_ID"),
    NOCO_VIEW_ID: getEnv("NOCO_VIEW_ID"),
    NOCO_TOKEN: getEnv("NOCO_TOKEN"),

    DATABASE_URL,
    NEON_DATABASE_URL,
    DB_CLIENT: (getEnv("DB_CLIENT") as AppEnv["DB_CLIENT"]) || undefined,
  };

  return out;
}
