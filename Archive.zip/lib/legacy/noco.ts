// src/lib/noco.ts
export async function fetchNoco() {
  throw new Error("NocoDB support removed. Use Postgres layer (src/lib/db.ts).");
}
